//
//  ViewModel.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

class ViewModel: ObservableObject {
    
    @Published var chats = [ChatModel]()
    @Published var isLoading = false
    @Published var didHaveSignInError = false
    @Published var textScale: CGFloat = 1.0
    
    private var uuid = UUID()
    static func preview() -> ViewModel {
        ViewModel(app: ApplicationController.preview())
    }
    
    @Published var navigationPath = NavigationPath()
    
    let app: ApplicationController
    init(app: ApplicationController) {
        self.app = app
        app.networkController.openSocketConnection()
        app.networkController.addObserver(AnyNetworkControllerObserver(observer: self))
    }
    
    func sendMessageIntent(_ text: String) {
        app.networkController.sendMessage(text)
    }
    
    func navigateToSettings() {
        navigationPath.append(self)
    }
    
    private var _loginID = 0
    func login(_ email: String, _ password: String) {
        
        if isLoading {
            didHaveSignInError = true
            return
        }
        if email.count <= 0 {
            didHaveSignInError = true
            return
        }
        
        isLoading = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) {
            ApplicationController.username = email
            self.isLoading = false
            self._loginID += 1
            let loginModel = LoginModel(email: email, password: password, id: "\(self._loginID)")
            self.navigationPath.append(loginModel)
        }
    }
    
}

extension ViewModel: NetworkControllerObserver {
    func networkControllerObserverDidReceiveChat(_ chat: ChatModel) {
        print("Did Receive Chat on MV: \(chat)")
        DispatchQueue.main.async {
            self.chats.append(chat)
        }
    }
}

extension ViewModel: Hashable {
    static func == (lhs: ViewModel, rhs: ViewModel) -> Bool {
        lhs.uuid == rhs.uuid
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(uuid)
    }
}
