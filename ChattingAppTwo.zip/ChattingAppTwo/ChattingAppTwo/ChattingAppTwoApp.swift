//
//  ChattingAppTwoApp.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

@main
struct ChattingAppTwoApp: App {
    let app = ApplicationController()
    var body: some Scene {
        WindowGroup {
            NavigationContainerView(viewModel: app.viewModel)
        }
    }
}
