//
//  LoginModel.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/21/22.
//

import Foundation

struct LoginModel {
    let email: String
    let password: String
    let id: String
}

extension LoginModel: Hashable, Identifiable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
