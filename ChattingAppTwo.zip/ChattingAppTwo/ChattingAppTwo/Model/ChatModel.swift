//
//  ChatModel.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import Foundation

struct ChatModel: Codable, Identifiable {
    let message: String
    let id: String
    let username: String
}
