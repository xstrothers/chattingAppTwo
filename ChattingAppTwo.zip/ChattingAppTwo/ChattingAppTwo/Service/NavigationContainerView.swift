//
//  NavigationContainerView.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

struct NavigationContainerView: View {
    
    @ObservedObject var viewModel: ViewModel
    var body: some View {
        NavigationStack(path: $viewModel.navigationPath) {
            LoginView(viewModel: viewModel)
        }
    }
}
