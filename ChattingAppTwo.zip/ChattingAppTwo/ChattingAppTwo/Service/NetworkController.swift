//
//  NetworkController.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import Foundation
import Starscream

protocol NetworkControllerObserver: AnyObject {
    func networkControllerObserverDidReceiveChat(_ chat: ChatModel)
}

class AnyNetworkControllerObserver: NetworkControllerObserver, Equatable {
    static func == (lhs: AnyNetworkControllerObserver, rhs: AnyNetworkControllerObserver) -> Bool {
        lhs === rhs
    }
    
    private weak var observer: (any NetworkControllerObserver)?
    required init(observer: any NetworkControllerObserver) {
        self.observer = observer
    }
    
    func networkControllerObserverDidReceiveChat(_ chat: ChatModel) {
        observer?.networkControllerObserverDidReceiveChat(chat)
    }
    
}

class NetworkController {
    
    private var socket: WebSocket?
    
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()
    
    private var _observers = [AnyNetworkControllerObserver]()
    func addObserver(_ observer: AnyNetworkControllerObserver) {
        for index in _observers.indices {
            if _observers[index] == observer { return }
        }
        _observers.append(observer)
    }
    
    func removeObserver(_ observer: AnyNetworkControllerObserver) {
        var repeatLoop = true
        while repeatLoop {
            repeatLoop = false
            for index in _observers.indices {
                if _observers[index] == observer {
                    _observers.remove(at: index)
                    repeatLoop = true
                    break
                }
            }
        }
    }
    
    func openSocketConnection() {
        
        print("Opening Socket Connection...")
        let port = 1337
        
        let urlString = "ws://localhost:\(port)/"
        print("Socket opening on \"\(urlString)\"")
        
        guard let url = URL(string: urlString) else {
            fatalError("Cannot get basic URL")
        }
        
        let urlRequest = URLRequest(url: url)
        
        self.socket = WebSocket(request: urlRequest)
        
        guard let socket = self.socket else {
            fatalError("Socket object does not exist.")
        }
        
        socket.delegate = self
        socket.connect()
    }
    
    private var _baseId = 0
    private func genId() -> String {
        let result = "\(_baseId)"
        _baseId += 1
        return result
    }
    
    func sendMessage(_ text: String) {
        print("Sending Message: \"\(text)\"")
        
        let username = ApplicationController.username
        let id = "\(username)-\(genId())"
        let message = text
        
        let chatObject = ChatModel(message: message, id: id, username: username)
        
        /*
        let jsonString = """
        {
            "message": "\(text)",
            "id": "\(id)",
            "username": "\(username)"
        }
        """
        */
        
        guard let data = try? encoder.encode(chatObject) else {
            fatalError("Could not encode chat model object")
        }
        
        guard let dataString = String(data: data, encoding: .utf8) else {
            fatalError("Could not encode data to string")
        }
        
        print("Sending message: \(dataString)")
        
        socket?.write(string: dataString) {
            print("Socket write complete...")
        }
    }
    
    func receiveMessage(_ text: String) {
        guard let data = text.data(using: .utf8) else {
            print("Could not get data from message: \(text)")
            return
        }
        
        guard let chatObject = try? decoder.decode(ChatModel.self, from: data) else {
            
            print("Could not decode chat object from data. \(text)")
            return
        }
        
        print("Received Chat Object: \(chatObject)")
        
        for obs in _observers {
            obs.networkControllerObserverDidReceiveChat(chatObject)
        }
        
    }
    
}

extension NetworkController: WebSocketDelegate {
    
    func didReceive(event: Starscream.WebSocketEvent, client: Starscream.WebSocketClient) {
        
        switch event {
            
        case .connected(_):
            print("Socket Connected!")
        case .disconnected(_, _):
            print("Socket Disconnected!")
        case .text(let text):
            print("Socket Received \"\(text)\"!")
            receiveMessage(text)
        case .binary(let data):
            print("Socket Received Binary Data... \(data.count) bytes")
        case .pong(_):
            print("Socket Pong")
        case .ping(_):
            print("Socket Ping")
        case .error(let error):
            print("Socket Error: \(error?.localizedDescription ?? "Unknown Error")")
        default:
            break
        }
        
    }
    
    
    
    
}
