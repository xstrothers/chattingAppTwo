//
//  ApplicationController.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import Foundation

class ApplicationController {
    
    static var username = ""
    
    static func preview() -> ApplicationController {
        return ApplicationController()
    }
    
    let networkController = NetworkController()
    
    lazy var viewModel: ViewModel = {
        ViewModel(app: self)
    }()
    
}
