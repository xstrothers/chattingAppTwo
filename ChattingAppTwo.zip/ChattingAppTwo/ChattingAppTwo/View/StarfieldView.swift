//
//  Starfield.swift
//  ChatterBox
//
//  Created by Nicky Taylor on 11/21/22.
//

import SwiftUI

class ScrollableStar {
    var x: CGFloat
    var y: CGFloat
    var color: UIColor
    let id = UUID()

    init(inColumn column: CGFloat, ofHeight height: CGFloat) {
        x = column
        y = CGFloat.random(in: 0..<height)

        color = UIColor(red: 1, green: 1, blue: 1, alpha: CGFloat.random(in: 0...1))
    }

    // Return false if the new position is offscreen (< 0)
    func moveBy(deltaX: CGFloat = 0, deltaY: CGFloat = 0) -> Bool {
        x += deltaX
        y += deltaY

        if x < 0 { return false }
        if y < 0 { return false }

        return true
    }
}

struct StarfieldView: View {
    @State var starDensity: Int = 2
    @State var stars = [ScrollableStar]()

    let timer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black

                ForEach(stars, id: \.id) { star in
                    Circle()
                        .frame(width: 1, height: 1, alignment: .center)
                        .position(x: star.x, y: star.y)
                        .foregroundColor(Color(star.color))
                }
            }
            .onReceive(timer) { _ in
                updateStars(width: geometry.size.width,
                            height: geometry.size.height,
                            density: starDensity)
            }
        }
        .edgesIgnoringSafeArea(.all)
    }

    private func updateStars(width: CGFloat, height: CGFloat, density: Int) {
        if self.stars.count == 0 {
            for column in stride(from: 0 as CGFloat, to: width, by: +1 as CGFloat) {
                addStarsTo(column: column, ofHeight: height, inStarArray: &self.stars, withDensity: density)
            }
        }

        var newStars = [ScrollableStar]()

        // Copy and move all stars to the left, add only those still in the field
        for star in self.stars {
            if star.moveBy(deltaX: -1) == true {
                newStars.append(star)
            }
        }

        // Add stars in right-most column
        addStarsTo(column: width-1, ofHeight: height, inStarArray: &newStars, withDensity: density)

        // Update once to prevent multiple view refreshes
        self.stars = newStars
    }

    private func addStarsTo(column: CGFloat,
                            ofHeight height: CGFloat,
                            inStarArray stars: inout [ScrollableStar],
                            withDensity density: Int) {

        let randomCount = Int.random(in: 0...density)
        for _ in 0..<randomCount {
            let star = ScrollableStar(inColumn: column, ofHeight: height)
            stars.append(star)
        }
    }
}
