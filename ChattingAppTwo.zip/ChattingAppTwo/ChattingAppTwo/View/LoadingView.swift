//
//  LoadingView.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/21/22.
//

import SwiftUI

struct LoadingView: View {
    let isLoading: Bool
    @ViewBuilder
    var body: some View {
        if isLoading {
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    ZStack {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(CGSize(width: 2.0, height: 2.0))
                            .padding(.all, 48)
                    }
                    .background(RoundedRectangle(cornerRadius: 12).fill().foregroundColor(.black.opacity(0.90)))
                    Spacer()
                }
                Spacer()
            }
            .background(Color.black.opacity(0.85))
        }
    }
}

struct LoadingView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingView(isLoading: true)
    }
}
