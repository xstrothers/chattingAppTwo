//
//  MessageBubbleRightAligned.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

struct MessageBubbleRightAligned: View {
    
    @ObservedObject var viewModel: ViewModel
    let text: String
    var body: some View {
        HStack(alignment: .top, spacing: 0) {
            Spacer()
            
            textBubble()
            
            Spacer()
                .frame(width: 4)
            
            HStack(alignment: .top) {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 28, height: 28)
                    .foregroundColor(Color("chat_bubble_2"))
                    
            }
            .padding(.top, 4)
        }
        .padding(.horizontal, 24)
        
    }
    
    func textBubble() -> some View {
        HStack {
            Spacer()
                .frame(width: 40)
            
            ZStack {
                HStack {
                    Text(text)
                        .font(Font.system(size: 22.0 * viewModel.textScale))
                        .foregroundColor(Color("chat_text_2"))
                        .padding(.all, 7)
                }
            }
            .background(speechBubble())
            Spacer()
                .frame(width: 6)
        }
    }
    
    func speechBubble() -> some View {
        ZStack {
            ZStack {
                BubbleShape()
                    .fill()
                    .foregroundColor(Color("chat_bubble_2"))
                BubbleShape()
                    .stroke()
                    .foregroundColor(Color("chat_bubble_2_border"))
            }
        }
        .scaleEffect(x: -1)
    }
}

struct MessageBubbleRightAligned_Previews: PreviewProvider {
    static var previews: some View {
        MessageBubbleRightAligned(viewModel: ViewModel.preview(), text: "Hello hello hello hello, chat chat chat chat")
    }
}
