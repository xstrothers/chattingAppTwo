//
//  MessageListView.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

struct MessageListView: View {
    @ObservedObject var viewModel: ViewModel
    @State var text = ""
    var body: some View {
        VStack {
            HStack {
                Spacer()
                
            }
            .padding(.trailing, 24)
            line()
            ScrollView {
                VStack(spacing: 20) {
                    ForEach(viewModel.chats) { chat in
                        chatRow(chat)
                    }
                }
            }
            Spacer()
            compose()
        }
        .navigationTitle("Chat Page")
        .navigationDestination(for: ViewModel.self) { viewModel in
            SettingsView(viewModel: viewModel)
        }
        .toolbar {
                    ToolbarItemGroup(placement: .navigationBarTrailing) {

                        Spacer()

                        Button(action: viewModel.navigateToSettings) {
                            Image(systemName: "gear")
                        
                        }
                    }
                }
    }
    
    private func fromMe(_ chat: ChatModel) -> Bool {
        chat.username == ApplicationController.username
    }
    
    @ViewBuilder
    private func chatRow(_ chat: ChatModel) -> some View {
        if fromMe(chat) {
            MessageBubbleLeftAligned(viewModel: viewModel, text: chat.message)
        } else {
            MessageBubbleRightAligned(viewModel: viewModel, text: chat.message)
        }
    }
    
    func line() -> some View {
        HStack {
            Spacer()
        }
        .frame(height: 1.0)
        .background(Color.gray)
    }
    
    func compose() -> some View {
        VStack {
            line()
            HStack(alignment: .top) {
                VStack {
                    VStack {
                        TextField("Enter Your Message", text: $text, axis: .vertical)
                            .padding(.all, 10)
                            .lineLimit(5, reservesSpace: true)
                            .foregroundColor(.black)
                    }
                    .background(RoundedRectangle(cornerRadius: 18).fill().foregroundColor(Color(red: 0.92, green: 0.92, blue: 0.94)))
                    .padding(.leading, 16)
                    
                }
                Button {
                    print("Sending Message: \(text)")
                    if text.count > 0 {
                        viewModel.sendMessageIntent(text)
                    }
                    self.text = ""
                } label: {
                    ZStack {
                        Image(systemName: "paperplane.fill")
                            .font(.system(size: 32))
                            .padding(.all, 5)
                    }
                }
                

                
            }
            .padding(.trailing, 24)
            
        }
        
    }
    
}

struct MessageListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            MessageListView(viewModel: ViewModel.preview())
        }
    }
}
