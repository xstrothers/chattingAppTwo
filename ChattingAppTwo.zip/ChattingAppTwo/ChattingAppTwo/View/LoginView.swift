//
//  LoginView.swift
//  iOSHelper
//
//  Created by Xavier Strothers on 11/20/22.
//

import SwiftUI
import CoreData

struct LoginView: View {
    
    @ObservedObject var viewModel: ViewModel
    @State private var email = ""
    @State private var password = ""
    
    var body: some View {
        VStack () {
            
            Text("Hello! Sign In")
                .font(.largeTitle).foregroundColor(Color.white)
                .padding([.top, .bottom], 40)
                .shadow(radius: 10.0, x: 20, y: 10)
                .bold()
            Image (systemName: "scribble.variable")
                .resizable()
                .renderingMode(.template)
                .foregroundColor(.white)
                .frame(width: 250, height: 250)
                .clipShape(Circle())
                .overlay(Circle().stroke( Color.white, lineWidth: 12))
                .shadow(radius: 10, x: 20, y: 10)
                .padding(.bottom, 50)
            
            VStack (alignment: .leading, spacing: 15) {
                
                usernameBar()
                
                passwordBar()
                
            }.padding([.leading, .trailing], 27.5)
            
            Button (action: {
                viewModel.login(email, password)
                
            }) {
                Text ("Sign In")
                    .font(.system(size: 24))
                    .foregroundColor(.white)
                    .padding()
                    .frame(width: 290, height: 50)
                    .background(Color.blue)
                    .cornerRadius(25.0)
            }.padding(.top, 50)
            
            Spacer()
            HStack (spacing: 0){
                Text ("Dont have an account? ")
                    .foregroundColor(.white)
                Button (action: {}) {
                    Text("Sign Up")
                }
            }
        }.background(
            StarfieldView()
        )
        .overlay(LoadingView(isLoading: viewModel.isLoading))
        .navigationDestination(for: LoginModel.self) { _ in
            
            MessageListView(viewModel: viewModel)
            
        }
        .alert("Couldn't sign in, please use your e-mail id.", isPresented: $viewModel.didHaveSignInError) {
            Button("Sounds Good") { }
        }
    }
    func usernameBar() -> some View {
        HStack {
            HStack {
                TextField("Username", text: $email)
                    .font(.system(size: 24))
                    .padding(.vertical, 6)
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 6)
            .background(Capsule().fill().foregroundColor(Color(red: 0.92, green: 0.92, blue: 0.92)))
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 6)
    }
    func passwordBar() -> some View {
        HStack {
            HStack {
                SecureField("Password", text: $password)
                    .font(.system(size: 24))
                    .padding(.vertical, 6)
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 6)
            .background(Capsule().fill().foregroundColor(Color(red: 0.92, green: 0.92, blue: 0.92)))
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 6)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(viewModel: ViewModel.preview())
    }
}


