//
//  MessageBubbleLeftAligned.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

struct MessageBubbleLeftAligned: View {
    
    @ObservedObject var viewModel: ViewModel
    let text: String
    var body: some View {
        HStack(alignment: .top, spacing: 0) {
            HStack(alignment: .top) {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 28, height: 28)
                    .foregroundColor(Color("chat_bubble_1"))
                    
            }
            .padding(.top, 4)
            
            Spacer()
                .frame(width: 4)
            
            textBubble()
            
            Spacer()
            
        }
        .padding(.horizontal, 24)
        
    }
    
    func textBubble() -> some View {
        HStack {
            Spacer()
                .frame(width: 6)
            ZStack {
                HStack {
                    Text(text)
                        .font(Font.system(size: 22.0 * viewModel.textScale))
                        .foregroundColor(Color("chat_text_1"))
                        .padding(.all, 7)
                }
            }
            .background(speechBubble())
            Spacer()
                .frame(width: 40)
        }
    }
    
    func speechBubble() -> some View {
        ZStack {
            BubbleShape()
                .fill()
                .foregroundColor(Color("chat_bubble_1"))
            BubbleShape()
                .stroke()
                .foregroundColor(Color("chat_bubble_1_border"))
        }
    }
    
}

struct MessageBubbleLeftAligned_Previews: PreviewProvider {
    static var previews: some View {
        MessageBubbleLeftAligned(viewModel: ViewModel.preview(), text: "Hello hello hello hello, chat chat chat chat")
    }
}
