//
//  BubbleShape.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

struct BubbleShape: Shape {
    
    private let cornerRadius: CGFloat = 10.0
    private let handleSize: CGFloat = 10.0
    
    func path(in rect: CGRect) -> Path {
        let handleOffset: CGFloat = 20.0
        
        var result = Path()
        result.move(to: CGPoint(x: rect.minX, y: rect.maxY - cornerRadius))
        result.addLine(to: CGPoint(x: rect.minX, y: handleOffset))
        result.addCurve(
            to: CGPoint(x: rect.minX, y: handleOffset - handleSize),
            control1: CGPoint(x: rect.minX - handleSize, y: handleOffset),
            control2: CGPoint(x: rect.minX, y: handleOffset - handleSize / 2)
        )
        result.addArc(
            center: CGPoint(x: rect.minX + cornerRadius, y: rect.minY + cornerRadius),
            radius: cornerRadius,
            startAngle: Angle(degrees: 180),
            endAngle: Angle(degrees: 270),
            clockwise: false
        )
        result.addArc(
            center: CGPoint(x: rect.maxX - cornerRadius, y: rect.minY + cornerRadius),
            radius: cornerRadius,
            startAngle: Angle(degrees: 270),
            endAngle: Angle(degrees: 0),
            clockwise: false
        )
        result.addArc(
            center: CGPoint(x: rect.maxX - cornerRadius, y: rect.maxY - cornerRadius),
            radius: cornerRadius,
            startAngle: Angle(degrees: 0),
            endAngle: Angle(degrees: 90),
            clockwise: false
        )
        result.addArc(
            center: CGPoint(x: rect.minX + cornerRadius, y: rect.maxY - cornerRadius),
            radius: cornerRadius,
            startAngle: Angle(degrees: 90),
            endAngle: Angle(degrees: 180),
            clockwise: false
        )
        return result
    }
    
}

