//
//  SettingsView.swift
//  ChattingAppTwo
//
//  Created by Xavier Strothers on 11/18/22.
//

import SwiftUI

struct SettingsView: View {
    @ObservedObject var viewModel: ViewModel
    
    @State var textScale: CGFloat = 1.0
    @State var someValue1: CGFloat = 10
    @State var someValue2: CGFloat = 6
    @State var someValue3: CGFloat = 4
    @State var someValue4: CGFloat = 3
    
    init(viewModel: ViewModel) {
        self.viewModel = viewModel
        self.textScale = viewModel.textScale
    }
    
    var body: some View {
        VStack {
            
            HStack {
                Text("Text Scale: ")
                Slider(value: $textScale, in: 0.5...2.0)
            }
            HStack {
                Text("Music: ")
                Slider(value: $someValue1, in: 0...10)
            }
            HStack {
                Text("SFX: ")
                Slider(value: $someValue2, in: 0...10)
            }
            HStack {
                Text("Graphics: ")
                Slider(value: $someValue3, in: 0...10)
            }
            HStack {
                Text("Particle Density: ")
                Slider(value: $someValue4, in: 0...10)
            }
            
        }
        .padding(.horizontal, 24)
        .navigationTitle("Settings")
        .onChange(of: textScale) { _ in
            viewModel.textScale = textScale
        }
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack{
            SettingsView(viewModel: ViewModel.preview())

        }
    }
}
